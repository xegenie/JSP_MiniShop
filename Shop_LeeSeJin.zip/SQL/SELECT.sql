-- SELECT
SELECT * FROM `user`;
SELECT * FROM `persistent_logins`;
SELECT * FROM `product`;
SELECT * FROM `product_io`;
SELECT * FROM `order`;